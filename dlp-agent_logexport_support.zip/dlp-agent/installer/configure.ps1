<#
    configure.ps1 -- install/uninstall side effects for the Prompt Firewall agent.

    Invoked by the MSI custom actions (deferred, runs as SYSTEM). Kept in
    PowerShell rather than raw WiX custom actions because the steps (generate CA,
    trust CA, set/reset WinINET proxy) are far clearer and easier to reverse here.

    Usage:
        configure.ps1 -Action Install   -InstallDir "C:\Program Files\PromptFirewallAgent"
        configure.ps1 -Action Uninstall -InstallDir "C:\Program Files\PromptFirewallAgent"
#>
param(
    [Parameter(Mandatory = $true)][ValidateSet("Install", "Uninstall")]$Action,
    [Parameter(Mandatory = $true)][string]$InstallDir,
    [int]$ProxyPort = 8080,
    [string]$ProxyHost = "127.0.0.1"
)

$ErrorActionPreference = "Stop"
$ConfDir = Join-Path $env:ProgramData "PromptFirewallAgent"
$CaCer = Join-Path $ConfDir "mitmproxy-ca-cert.cer"
$InetKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
$ProxyServer = "$ProxyHost`:$ProxyPort"

function Write-Log($msg) {
    $logDir = Join-Path $ConfDir "logs"
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    Add-Content -Path (Join-Path $logDir "install.log") -Value "$(Get-Date -Format o) $msg" -Encoding utf8
}

if ($Action -eq "Install") {
    Write-Log "Install: generating + trusting CA, setting proxy."

    # 1. Generate the mitmproxy root CA into ProgramData (idempotent).
    New-Item -ItemType Directory -Force -Path $ConfDir | Out-Null
    if (-not (Test-Path $CaCer)) {
        & (Join-Path $InstallDir "PromptFirewallService.exe") "--gen-ca" $ConfDir | Out-Null
    }

    # 2. Trust it machine-wide (Local Machine Root store).
    if (Test-Path $CaCer) {
        & certutil.exe -addstore -f Root $CaCer | Out-Null
        Write-Log "CA added to LocalMachine\Root."
    } else {
        Write-Log "WARNING: CA file not found at $CaCer; TLS interception will fail."
    }

    # 3. Point the WinINET system proxy at the local agent (covers Edge/Chrome).
    Set-ItemProperty -Path $InetKey -Name ProxyServer -Value $ProxyServer
    Set-ItemProperty -Path $InetKey -Name ProxyEnable -Value 1 -Type DWord
    Write-Log "WinINET proxy set to $ProxyServer."

    # 4. Register + start the Windows service using the frozen exe's own verbs
    #    (the pywin32-correct way; MSI ServiceInstall doesn't fit a PyInstaller
    #    pywin32 service). Non-fatal so a service hiccup doesn't fail the MSI.
    $svcExe = Join-Path $InstallDir "PromptFirewallService.exe"
    if (Test-Path $svcExe) {
        try {
            & $svcExe "install" | Out-Null
            & $svcExe "start" | Out-Null
            Write-Log "Service PromptFirewallAgent installed and started."
        } catch { Write-Log "Service install/start failed: $_" }
    } else {
        Write-Log "WARNING: $svcExe not found; service not installed."
    }
}
elseif ($Action -eq "Uninstall") {
    Write-Log "Uninstall: stopping service, reverting proxy + CA trust."

    # 0. Stop + remove the service (runs before files are deleted).
    $svcExe = Join-Path $InstallDir "PromptFirewallService.exe"
    if (Test-Path $svcExe) {
        try {
            & $svcExe "stop" | Out-Null
            & $svcExe "remove" | Out-Null
            Write-Log "Service PromptFirewallAgent stopped and removed."
        } catch { Write-Log "Service stop/remove failed: $_" }
    }

    # 1. Reset the proxy.
    try {
        Set-ItemProperty -Path $InetKey -Name ProxyEnable -Value 0 -Type DWord
        Remove-ItemProperty -Path $InetKey -Name ProxyServer -ErrorAction SilentlyContinue
    } catch { Write-Log "proxy reset failed: $_" }

    # 2. Remove the CA from the machine Root store by its subject (CN=mitmproxy).
    try {
        & certutil.exe -delstore Root "mitmproxy" | Out-Null
        Write-Log "CA removed from LocalMachine\Root."
    } catch { Write-Log "CA removal failed: $_" }
}