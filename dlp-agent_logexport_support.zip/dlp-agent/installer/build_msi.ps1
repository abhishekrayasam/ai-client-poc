<#
    build_msi.ps1 -- build the Prompt Firewall MSI from the PyInstaller output.

    Prereqs on the build machine:
        dotnet tool install --global wix          # WiX v4/v5 CLI
        wix extension add -g WixToolset.Util.wixext
        # and the PyInstaller build already done:  pyinstaller build/agent.spec

    Run from the dlp-agent folder:
        powershell -ExecutionPolicy Bypass -File installer\build_msi.ps1
#>
param(
    [string]$PayloadDir = "..\dist\PromptFirewallClient",
    [string]$Output = "PromptFirewallAgent.msi"
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

$resolvedPayload = Resolve-Path (Join-Path $here $PayloadDir) -ErrorAction SilentlyContinue
if (-not $resolvedPayload) {
    throw "Payload not found at $PayloadDir. Run 'pyinstaller build/agent.spec' first."
}

# Stage configure.ps1 into the payload so it installs to [INSTALLDIR]configure.ps1
Copy-Item -Force (Join-Path $here "configure.ps1") (Join-Path $resolvedPayload "configure.ps1")
Write-Host "Staged configure.ps1 into payload."

# Ensure the Util extension (WixQuietExec) is available.
wix extension add WixToolset.Util.wixext | Out-Null

Write-Host "Building MSI..."
wix build Product.wxs `
    -ext WixToolset.Util.wixext `
    -o $Output

Write-Host "Done -> $(Join-Path $here $Output)"
Write-Host "Install (elevated):  msiexec /i $Output /l*v install.log"