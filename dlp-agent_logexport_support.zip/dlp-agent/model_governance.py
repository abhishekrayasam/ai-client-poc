"""
Local-AI model governance.

Blocks (or flags) requests to a self-hosted LLM runtime -- Ollama, LM Studio, or
any OpenAI-compatible "desktop agent" -- when the model being invoked is NOT on a
preconfigured allow-list. This is the on-device equivalent of "only approved
models may be used," independent of the PII/prompt firewall.

How it fits the agent:
  * proxy_runner.configure() pushes the "model_governance" config block here once.
  * proxy_addon calls evaluate_request() on every request; a returned decision is
    surfaced to the GUI and, when action == BLOCK, the request is 403'd.

Scope / honesty note:
  This only fires on traffic that actually reaches the inspector. A LOCAL app
  talking to a LOCAL runtime over loopback (127.0.0.1:11434) is typically NOT
  captured by the Windows proxy or WinDivert "local" mode (loopback is special-
  cased / bypassed). It reliably governs runtimes reached over the real network
  (a LAN/remote Ollama, or a desktop agent not bound to pure loopback). See the
  README for how to make a local runtime visible.

This is an AGENT-ONLY capability; it is intentionally NOT part of the
prompt_firewall_poc.py CLI.
"""

import json
import logging
from typing import Any, Dict, List, Optional

import ai_hosts

log = logging.getLogger("promptfirewall.models")

# ---- configuration (set by configure(); safe defaults = feature OFF) ---------
ENABLED: bool = False
WHITELIST: List[str] = []
# What to do with a model that is NOT on the allow-list / cannot be parsed.
ON_UNKNOWN_MODEL: str = "BLOCK"   # BLOCK | FLAG | ALLOW
ON_UNPARSEABLE: str = "FLAG"      # inference call whose "model" field is missing

# Cloud / browser model governance. OFF by default and SEPARATELY opt-in: turning
# it on means cloud model names (gpt-4o, claude-*, ...) must also be allow-listed,
# so it must not be implied by the local-runtime switch.
GOVERN_CLOUD: bool = False
CLOUD_WHITELIST: List[str] = []   # falls back to WHITELIST when empty

# Destination ports that unambiguously mean "a local LLM runtime." Overridable
# via config ("runtimes": [{"name": ..., "ports": [...]}, ...]).
_RUNTIME_PORTS: Dict[str, set] = {
    "ollama": {11434},
    "lmstudio": {1234},
}

# Request paths that actually RUN a model (carry a "model" field). Discovery /
# management paths (/api/tags, /v1/models, /api/pull, ...) are deliberately left
# alone -- they don't invoke a model, so there is nothing to govern.
_INFERENCE_PATHS = (
    "/api/generate", "/api/chat", "/api/embeddings", "/api/embed",
    "/v1/chat/completions", "/v1/completions", "/v1/embeddings",
)
# OpenAI-compatible inference paths used to spot a "desktop agent" on any port.
_OPENAI_PATHS = ("/v1/chat/completions", "/v1/completions", "/v1/embeddings")

# Cloud / browser providers. Each rule names where the model lives:
#   extract="body"       -> top-level JSON "model" field (OpenAI/Anthropic APIs,
#                           ChatGPT + Claude web backends).
#   extract="google_url" -> model is in the URL (.../models/{model}:generate...).
# "require" (optional): the path must also contain one of these substrings, so we
# only govern the actual inference call, not every path under the prefix.
# NOTE: gemini.google.com (the consumer web app) is intentionally absent -- it
# sends an opaque batchexecute RPC that does not carry an identifiable model, so
# it cannot be governed reliably. The official Google API below can.
_CLOUD_PROVIDERS = (
    ("api.openai.com", {"name": "openai-api", "extract": "body",
                        "paths": ("/v1/chat/completions", "/v1/completions",
                                  "/v1/responses", "/v1/embeddings")}),
    ("api.anthropic.com", {"name": "anthropic-api", "extract": "body",
                           "paths": ("/v1/messages", "/v1/complete")}),
    ("generativelanguage.googleapis.com", {"name": "google-api",
                                           "extract": "google_url",
                                           "paths": ("/v1beta/models/",
                                                     "/v1beta1/models/",
                                                     "/v1/models/")}),
    ("chatgpt.com", {"name": "chatgpt-web", "extract": "body",
                     "paths": ("/backend-api/conversation",
                               "/backend-api/f/conversation")}),
    ("chat.openai.com", {"name": "chatgpt-web", "extract": "body",
                         "paths": ("/backend-api/conversation",
                                   "/backend-api/f/conversation")}),
    ("claude.ai", {"name": "claude-web", "extract": "body",
                   "paths": ("/api/",), "require": ("completion",)}),
)


def configure(cfg: Optional[Dict[str, Any]]) -> None:
    """Load the "model_governance" config block (called once at proxy start)."""
    global ENABLED, WHITELIST, ON_UNKNOWN_MODEL, ON_UNPARSEABLE, _RUNTIME_PORTS
    global GOVERN_CLOUD, CLOUD_WHITELIST
    cfg = cfg or {}
    ENABLED = bool(cfg.get("enabled", False))
    WHITELIST = [str(x) for x in (cfg.get("whitelist") or [])]
    ON_UNKNOWN_MODEL = str(cfg.get("on_unknown_model", "block")).upper()
    ON_UNPARSEABLE = str(cfg.get("on_unparseable", "flag")).upper()
    GOVERN_CLOUD = bool(cfg.get("govern_cloud", False))
    CLOUD_WHITELIST = [str(x) for x in (cfg.get("cloud_whitelist") or [])]
    runtimes = cfg.get("runtimes")
    if runtimes:
        _RUNTIME_PORTS = {
            str(r["name"]): set(r.get("ports", []) or [])
            for r in runtimes if r.get("name")
        }
    if ENABLED:
        log.info("Model governance ON: %d local + %d cloud model(s) allow-listed, "
                 "unknown->%s, govern_cloud=%s, runtimes=%s", len(WHITELIST),
                 len(CLOUD_WHITELIST), ON_UNKNOWN_MODEL, GOVERN_CLOUD,
                 ",".join(_RUNTIME_PORTS))
    else:
        log.info("Model governance OFF.")


def match_runtime(host: str, port: int, path: str) -> Optional[str]:
    """Name of the local-AI runtime this request targets, or None.

    Matches by well-known runtime port first (covers any path on that port),
    then by Ollama's native API path, then by a generic OpenAI-compatible
    inference path on a host that is NOT one of the known cloud providers (so a
    self-hosted / desktop agent on an arbitrary port is still caught, while
    cloud traffic keeps flowing through the normal DLP path).
    """
    path = path or ""
    for name, ports in _RUNTIME_PORTS.items():
        if port in ports:
            return name
    if path.startswith("/api/chat") or path.startswith("/api/generate"):
        return "ollama"
    if any(path.startswith(p) for p in _OPENAI_PATHS) and not ai_hosts.is_ai_host(host):
        return "openai-compatible"
    return None


def _is_inference_path(path: str) -> bool:
    path = path or ""
    return any(path.startswith(p) for p in _INFERENCE_PATHS)


def extract_model(raw_body: bytes) -> Optional[str]:
    """Pull the top-level "model" field from a JSON request body, or None.

    Ollama (/api/generate, /api/chat) and every OpenAI-compatible body carry the
    model name at the top level, so a single lookup covers all the runtimes.
    """
    if not raw_body:
        return None
    try:
        body = json.loads(raw_body.decode("utf-8", errors="replace"))
    except (ValueError, TypeError):
        return None
    if isinstance(body, dict):
        model = body.get("model")
        if isinstance(model, str) and model.strip():
            return model.strip()
    return None


def model_allowed(model: str, whitelist: Optional[List[str]] = None) -> bool:
    """True if ``model`` is permitted by ``whitelist`` (default: the local list).

    Matching is case-insensitive:
      * ``*``            permits anything (audit-only, combine with on_unknown_model).
      * ``gpt-4o*``      prefix match -- permits any model starting with ``gpt-4o``
                         (handy for cloud models with dated suffixes).
      * ``llama3.1:8b``  entry WITH a tag -> exact match.
      * ``llama3.1``     entry WITHOUT a tag -> that model at any tag (llama3.1:8b).
    """
    wl = WHITELIST if whitelist is None else whitelist
    m = (model or "").strip().lower()
    if not m:
        return False
    family = m.split(":", 1)[0]
    for entry in wl:
        e = entry.strip().lower()
        if not e:
            continue
        if e == "*":
            return True
        if e.endswith("*"):
            if m.startswith(e[:-1]):
                return True
        elif ":" in e:
            if m == e:
                return True
        elif e == m or e == family:
            return True
    return False


def _google_url_model(path: str) -> Optional[str]:
    """Pull the model from a Google API URL: .../models/{model}:generateContent."""
    marker = "models/"
    idx = (path or "").find(marker)
    if idx == -1:
        return None
    rest = path[idx + len(marker):]
    for sep in (":", "/", "?"):
        j = rest.find(sep)
        if j != -1:
            rest = rest[:j]
    return rest.strip() or None


def match_cloud(host: str, path: str) -> Optional[Dict[str, Any]]:
    """The cloud/browser provider rule this request targets, or None."""
    host = (host or "").lower()
    path = path or ""
    for suffix, rule in _CLOUD_PROVIDERS:
        if host == suffix or host.endswith("." + suffix):
            if any(path.startswith(p) for p in rule["paths"]):
                require = rule.get("require")
                if require and not any(r in path for r in require):
                    continue
                return rule
    return None


def _extract_cloud_model(rule: Dict[str, Any], path: str,
                         raw_body: bytes) -> Optional[str]:
    if rule.get("extract") == "google_url":
        return _google_url_model(path)
    return extract_model(raw_body)   # top-level JSON "model" field


def _decision(action: str, source: str, model: str,
              reason: str) -> Optional[Dict[str, Any]]:
    """Build a surfaced decision, or None when the resolved action is ALLOW."""
    action = (action or "BLOCK").upper()
    if action == "ALLOW":
        return None
    phase = "MODEL_NOT_WHITELISTED" if action == "BLOCK" else "MODEL_GOVERNANCE_FLAG"
    return {
        "runtime": source,
        "model": model,
        "action": action,
        "phase": phase,
        "categories": ["unapproved_model"],
        "matched": f"{source}:{model}",
        "reason": reason,
    }


def _judge(source: str, model: Optional[str], whitelist: List[str],
           unknown_reason: str) -> Optional[Dict[str, Any]]:
    """Shared verdict: unparseable -> flag, not-allowed -> block, allowed -> None."""
    if not model:
        return _decision(ON_UNPARSEABLE, source, "(unspecified)",
                         "inference call with no parseable model")
    if model_allowed(model, whitelist):
        return None
    return _decision(ON_UNKNOWN_MODEL, source, model, unknown_reason)


def evaluate_request(host: str, port: int, path: str,
                     raw_body: bytes) -> Optional[Dict[str, Any]]:
    """Governance verdict for one request, or None to proceed normally.

    None  -> governance off, not governed, a non-inference call, or the model is
             approved. The caller continues (incl. the DLP prompt scan).
    dict  -> a decision to publish; action == BLOCK means 403 the request.
    """
    if not ENABLED:
        return None

    # Local / self-hosted runtimes (Ollama, LM Studio, desktop agents).
    runtime = match_runtime(host, port, path)
    if runtime:
        if not _is_inference_path(path):
            return None  # discovery / management call -> nothing to govern
        return _judge(runtime, extract_model(raw_body), WHITELIST,
                      "model not on the approved allow-list")

    # Cloud / browser providers (separately opt-in).
    if GOVERN_CLOUD:
        rule = match_cloud(host, path)
        if rule:
            wl = CLOUD_WHITELIST or WHITELIST
            model = _extract_cloud_model(rule, path, raw_body)
            return _judge(rule["name"], model, wl,
                          "cloud model not on the approved allow-list")
    return None


# --------------------------------------------------------------------------- #
# Self-test
# --------------------------------------------------------------------------- #
def _selftest() -> int:
    configure({
        "enabled": True,
        "on_unknown_model": "block",
        "on_unparseable": "flag",
        "whitelist": ["llama3.1", "qwen2.5:0.5b"],
    })

    def body(model=None, **extra):
        d = dict(extra)
        if model is not None:
            d["model"] = model
        return json.dumps(d).encode("utf-8")

    # (host, port, path, body, expected_action_or_None)
    cases = [
        # Ollama by port, approved family tag -> allowed (None).
        ("127.0.0.1", 11434, "/api/chat", body("llama3.1:8b", messages=[]), None),
        # Ollama, unknown model -> BLOCK.
        ("127.0.0.1", 11434, "/api/generate", body("deepseek-r1", prompt="hi"), "BLOCK"),
        # LM Studio by port, exact tag match -> allowed.
        ("127.0.0.1", 1234, "/v1/chat/completions", body("qwen2.5:0.5b"), None),
        # LM Studio, exact-tag list entry but wrong tag -> BLOCK.
        ("127.0.0.1", 1234, "/v1/chat/completions", body("qwen2.5:7b"), "BLOCK"),
        # Desktop agent (OpenAI-compatible) on an odd port, unknown -> BLOCK.
        ("10.0.0.5", 8000, "/v1/chat/completions", body("gpt-4o-local"), "BLOCK"),
        # Discovery call (model list) -> never governed (None), even on a runtime port.
        ("127.0.0.1", 11434, "/api/tags", b"", None),
        # Inference call with no model field -> FLAG (on_unparseable).
        ("127.0.0.1", 11434, "/api/chat", body(messages=[]), "FLAG"),
        # Non-runtime host/port -> not governed.
        ("example.com", 443, "/search", b"", None),
        # Cloud host, govern_cloud OFF -> left to the DLP path, not governed here.
        ("api.openai.com", 443, "/v1/chat/completions", body("gpt-4o"), None),
    ]

    # Cloud / browser cases (run below with govern_cloud ON + a cloud allow-list).
    cloud_cases = [
        # OpenAI API, prefix match on a dated slug -> allowed.
        ("api.openai.com", 443, "/v1/chat/completions", body("gpt-4o-2024-08-06"), None),
        # OpenAI API, model not listed -> BLOCK.
        ("api.openai.com", 443, "/v1/chat/completions", body("gpt-3.5-turbo"), "BLOCK"),
        # Anthropic API, prefix match -> allowed.
        ("api.anthropic.com", 443, "/v1/messages", body("claude-3-5-sonnet-20241022"), None),
        # Google API, model in the URL path -> BLOCK (not listed).
        ("generativelanguage.googleapis.com", 443,
         "/v1beta/models/gemini-1.5-flash:generateContent", b"", "BLOCK"),
        # Google API, model in the URL path -> allowed.
        ("generativelanguage.googleapis.com", 443,
         "/v1beta/models/gemini-1.5-pro:generateContent", b"", None),
        # ChatGPT web backend, consumer model slug not listed -> BLOCK.
        ("chatgpt.com", 443, "/backend-api/conversation", body("o1-preview"), "BLOCK"),
        # Claude web backend completion, allowed via prefix -> None.
        ("claude.ai", 443,
         "/api/organizations/x/chat_conversations/y/completion",
         body("claude-3-5-sonnet-20241022"), None),
        # Claude web, a non-completion /api path -> not governed.
        ("claude.ai", 443, "/api/organizations/x/projects", b"", None),
    ]

    failures = 0
    print("\nModel-governance self-test\n" + "=" * 60)
    all_cases = [("local", cases), ("cloud", cloud_cases)]
    # Re-apply local-only config for the first batch, cloud config for the second.
    n = 0
    for label, batch in all_cases:
        if label == "local":
            configure({"enabled": True, "on_unknown_model": "block",
                       "on_unparseable": "flag",
                       "whitelist": ["llama3.1", "qwen2.5:0.5b"]})
        else:
            configure({"enabled": True, "govern_cloud": True,
                       "on_unknown_model": "block", "on_unparseable": "flag",
                       "whitelist": ["llama3.1", "qwen2.5:0.5b"],
                       "cloud_whitelist": ["gpt-4o*", "claude-3-5-sonnet*",
                                           "gemini-1.5-pro"]})
        for host, port, path, raw, expected in batch:
            n += 1
            got = evaluate_request(host, port, path, raw)
            action = got["action"] if got else None
            ok = action == expected
            failures += not ok
            mark = "PASS" if ok else "FAIL"
            model = got.get("model") if got else "-"
            print(f"[{mark}] {n:2d}. [{label}] {host}{path[:34]:35s} -> "
                  f"{str(action):5s} (model={model})")

    print(f"\n{n - failures}/{n} cases passed.")
    return 1 if failures else 0


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        raise SystemExit(_selftest())
    print("model_governance.py is a library. Run with --selftest.")
