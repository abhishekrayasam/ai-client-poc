"""
Quick local harness for the local-AI model-governance feature.

Part A (always runs; no mitmproxy needed): drives model_governance.evaluate_request
directly on sample Ollama / LM Studio / desktop-agent request bodies and prints the
ALLOW / FLAG / BLOCK verdict, plus the 403 JSON a blocked client would receive.

Part B (runs only where mitmproxy is installed -- i.e. the agent machine): builds a
real mitmproxy HTTPFlow and runs it through the actual PromptFirewallAddon.request
handler, asserting a disallowed model gets a 403 and an allowed one passes through.

Run:
    python test_model_governance.py
"""

import asyncio
import json

import model_governance

DEMO_CFG = {
    "enabled": True,
    "govern_cloud": True,
    "on_unknown_model": "block",
    "on_unparseable": "flag",
    "whitelist": ["llama3.1", "qwen2.5", "mistral"],
    "cloud_whitelist": ["gpt-4o*", "claude-3-5-sonnet*", "gemini-1.5-pro"],
}

# (host, port, path, model)  -- model=None means "no model field in the body"
SAMPLES = [
    # Local / self-hosted.
    ("ollama.lan", 11434, "/api/chat", "llama3.1:8b"),          # approved family tag
    ("ollama.lan", 11434, "/api/generate", "deepseek-r1:14b"),  # BLOCK (not listed)
    ("lmstudio.lan", 1234, "/v1/chat/completions", "qwen2.5"),  # approved
    ("desktop.lan", 8000, "/v1/chat/completions", "wizard-uncensored"),  # BLOCK (agent)
    ("ollama.lan", 11434, "/api/chat", None),                   # FLAG (no model field)
    ("ollama.lan", 11434, "/api/tags", None),                   # not governed (discovery)
    # Cloud / browser (govern_cloud).
    ("api.openai.com", 443, "/v1/chat/completions", "gpt-4o-2024-08-06"),  # approved (prefix)
    ("api.openai.com", 443, "/v1/chat/completions", "gpt-3.5-turbo"),      # BLOCK
    ("api.anthropic.com", 443, "/v1/messages", "claude-3-5-sonnet-20241022"),  # approved
    ("generativelanguage.googleapis.com", 443,
     "/v1beta/models/gemini-1.5-flash:generateContent", None),  # BLOCK (model in URL)
    ("chatgpt.com", 443, "/backend-api/conversation", "o1-preview"),  # BLOCK (web)
]


def _body(model=None, prompt="hello there"):
    d = {"messages": [{"role": "user", "content": prompt}]}
    if model is not None:
        d["model"] = model
    return json.dumps(d).encode("utf-8")


def part_a() -> None:
    print("Part A — model_governance.evaluate_request (no mitmproxy needed)")
    print("=" * 72)
    model_governance.configure(DEMO_CFG)
    for host, port, path, model in SAMPLES:
        body = _body(model) if path not in ("/api/tags",) else b""
        gov = model_governance.evaluate_request(host, port, path, body)
        if gov is None:
            print(f"  ALLOW  {host}:{port}{path:24s} model={model}")
        else:
            print(f"  {gov['action']:5s}  {host}:{port}{path:24s} "
                  f"model={gov['model']}  [{gov['phase']}] — {gov['reason']}")

    gov = model_governance.evaluate_request(
        "ollama.lan", 11434, "/api/chat", _body("deepseek-r1:14b"))
    print("\n  403 body a blocked client receives:")
    try:
        from proxy_addon import _model_block_body
        print("   ", _model_block_body(gov["model"], gov["runtime"]).decode())
    except Exception as exc:
        print(f"    (proxy_addon needs mitmproxy to import here: {exc})")


def part_b() -> None:
    try:
        from mitmproxy.test import tflow, tutils
        import proxy_addon
        from engine import DetectionEngine
    except Exception as exc:
        print(f"\nPart B — SKIPPED (mitmproxy not importable here: {exc})")
        print("         Run this on the agent machine to exercise the real addon.")
        return

    print("\nPart B — real PromptFirewallAddon.request() path")
    print("=" * 72)
    model_governance.configure(DEMO_CFG)
    published = []
    proxy_addon.DECISION_SINK = published.append
    engine = DetectionEngine()            # SLM optional; 'hello' takes the fast path
    addon = proxy_addon.PromptFirewallAddon(engine=engine)

    def make_flow(host, port, path, model):
        req = tutils.treq(method=b"POST", scheme=b"http", host=host, port=port,
                          path=path.encode(), content=_body(model))
        return tflow.tflow(req=req)

    # Disallowed model -> expect a 403 injected by the addon.
    f = make_flow("ollama.lan", 11434, "/api/chat", "deepseek-r1:14b")
    asyncio.run(addon.request(f))
    assert f.response is not None and f.response.status_code == 403, \
        "disallowed model should be blocked with 403"
    print(f"  BLOCK ok  -> status {f.response.status_code}")
    print("   body:", f.response.content.decode())

    # Allowed model -> request passes through (addon sets no response).
    f2 = make_flow("ollama.lan", 11434, "/api/chat", "llama3.1:8b")
    asyncio.run(addon.request(f2))
    assert f2.response is None, "allowed model should pass through"
    print("  ALLOW ok  -> request passed through (no block)")

    # Cloud: disallowed model on the OpenAI API -> 403.
    fc = make_flow("api.openai.com", 443, "/v1/chat/completions", "gpt-3.5-turbo")
    asyncio.run(addon.request(fc))
    assert fc.response is not None and fc.response.status_code == 403, \
        "disallowed cloud model should be blocked with 403"
    print(f"  CLOUD BLOCK ok -> status {fc.response.status_code}")

    # Cloud: allowed model (prefix match) -> pass-through.
    fc2 = make_flow("api.openai.com", 443, "/v1/chat/completions", "gpt-4o-2024-08-06")
    asyncio.run(addon.request(fc2))
    assert fc2.response is None, "allowed cloud model should pass through"
    print("  CLOUD ALLOW ok -> request passed through (no block)")

    print("\n  decisions published to the GUI sink: "
          f"{[(d.get('action'), d.get('matched')) for d in published]}")
    print("\nPart B PASS")


if __name__ == "__main__":
    part_a()
    part_b()
